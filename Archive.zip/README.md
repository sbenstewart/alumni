# alumni
A basic prototype for a college alumni website.
## How to contribute
Just the usual git clone and pull request for development. No other contribution restriction and so on.
## What to contribute
The issues to be fixed will be posted in the issues tab which you can take to solve.<br>
A comment right there down the issue would help other contributors know that you are working on it.<br>
Trust me this saves a lot of time.
## RoadMap
It is for now the template for the Alumni of Tiruvannamalai Medical College.
## What it currently is.
The templates for the front end have been selected.Those templates have to be modified to fit our description.
<br>
Which is <br>
* Landing page with login button
* Login/Registration page
* The main page
* The user detail entry point
* The base user resume page
## More to convey
The front end is fixed to html, css, bootstrap ( which makes the site responsive ie. can be viewed on all resolutions).<br>
The back end is mysql which I think would serve the purpose.<br>
Suggestions are welcome.<br>
Have a great day.
