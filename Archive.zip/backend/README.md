# How to use the files
The schema.png is for you to get a better understanding of how the schema is. Just kidding.
<br>
To use the dump.sql use the following steps.
<br>
- Open phpMyAdmin
- Create a database named alumni
- Select the import tab in the admin page
- Select the dump.sql file and then click the go option
<br>
The above steps gives you the datadump loaded into the backend solution you havegot.
<br>
<b>Have a great day</b>
